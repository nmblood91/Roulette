package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class Insight {
    int wager;
    int outcome;
    double avg;
    double stddev;
    float cdf;
    float y_axis_spread;
    float x_axis_height;
    RectF insight_area;
    RectF histogram;
    ArrayList<RectF> histogram_bars;
    String message;

    public Insight(RectF insight_area, ArrayList<Bet> betlist){

        this.insight_area = insight_area;
        TreeMap<Integer, Integer> outcome_histogram = new TreeMap();

        for(Bet b: betlist){
            wager+= b.getChip().getValue();
        }


        for (int r =1; r <= 38; r++){

            outcome = -1 * wager;

            for(Bet b: betlist){
                if(b.did_win(r))
                    outcome += b.getChip().getValue() *(1+b.getPayout());
            }

            if (!outcome_histogram.containsKey(new Integer(outcome)))
            outcome_histogram.put(outcome,1);
               else
            outcome_histogram.put(outcome,outcome_histogram.get(outcome) + 1);

            avg += outcome/38.0;

        }


//make histogram
        histogram = new RectF(insight_area.left + .05f*insight_area.width(), insight_area.top + .05f*insight_area.height(), insight_area.left + .95f*insight_area.width(), insight_area.top + .95f*insight_area.height());
        histogram_bars = new ArrayList<>();

        y_axis_spread = outcome_histogram.lastEntry().getKey() - outcome_histogram.firstEntry().getKey();
        x_axis_height = -1* (outcome_histogram.firstEntry().getKey()/y_axis_spread) * histogram.width();

        message = "        Outcomes   |   Percent Chance\n";
        message = message.concat("---------------------------------------------------------------------------\n");

        for (Map.Entry<Integer,Integer> entry: outcome_histogram.entrySet()){

            int outcome = entry.getKey();
            int frequency = entry.getValue();

            float percent = frequency/38f;

            if (outcome>0) {
                histogram_bars.add(new RectF(histogram.left + x_axis_height, histogram.top + cdf * histogram.height(), histogram.left + x_axis_height + (outcome / y_axis_spread) * histogram.width(), histogram.top + (cdf + percent) * histogram.height()));
                message = message.concat("Win " + outcome + "   " + String.format("%.1f",100*percent) + "%\n");
            } else if(outcome < 0) {
                histogram_bars.add(new RectF(histogram.left + x_axis_height + (outcome / y_axis_spread) * histogram.width(), histogram.top + cdf * histogram.height(), histogram.left + x_axis_height, histogram.top + (cdf + percent) * histogram.height()));
                message = message.concat(" Lose " + (-1)*outcome + "   " + String.format("%.1f",100*percent) + "%\n");
            }else
                message = message.concat("Break Even   " +String.format("%.1f",100*percent) + "%\n");

            cdf += percent;
            stddev += frequency * Math.pow((outcome - avg),2);

        }

        stddev = Math.sqrt(stddev/38f);

        message = message.concat("\n\nExpected Value: " + String.format("%.2f",avg));
        message = message.concat("\nExpected % Return: " + String.format("%.1f",avg/wager*100) + "%");
        message = message.concat("\nStandard Deviation: " + String.format("%.2f",stddev));



    }

    public void drawInsight(Canvas c, Paint p){

        p.setColor(Color.GRAY);
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        c.drawRect(insight_area,p);

        p.setColor(Color.WHITE);
       // p.setStyle(Paint.Style.STROKE);

        p.setStyle(Paint.Style.FILL);

        for (RectF bar: histogram_bars) {

            if (bar.centerX() <histogram.left + x_axis_height)
                p.setColor(Color.RED);
            else
                p.setColor(Color.GREEN);

            c.drawRect(bar,p);



        }

        p.setColor(Color.BLUE);
        c.drawLine(histogram.left + x_axis_height, histogram.top, histogram.left + x_axis_height, histogram.bottom, p);

        p.setColor(Color.WHITE);

        for (int x=0; x<9; x++) {

            float tick_height;

            if (x % 2 ==0)
                tick_height = 10;
            else
                tick_height = 5;

            c.drawLine(histogram.left + x_axis_height + tick_height, histogram.top + .125f *x* histogram.height(), histogram.left + x_axis_height - tick_height, histogram.top + .125f *x* histogram.height(), p);
        }

        p.setTextSize(20);

        c.rotate(90,histogram.right,histogram.top);
        float x = histogram.right + .2f*histogram.height(), y = histogram.top;

        int lines = 0;

        for (String line: message.split("\n")) {

            c.drawText(line, x, y, p);

            lines++;

            x = histogram.right + .2f*histogram.height() + lines/15*.3f*histogram.height();
            y = histogram.top + (p.descent() - p.ascent())*lines  - lines/15 * (p.descent() - p.ascent())*13;

        }

        c.rotate(-90,histogram.right,histogram.top );
    }



}
