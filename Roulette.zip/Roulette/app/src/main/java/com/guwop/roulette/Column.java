package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Column extends Bet {

    String type;
    String text;

    public Column(String type, RectF area){
        this.area=area;
        this.type = type;
        payout = 2;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return spin_result <= 36 && ( (spin_result % 3 == 1  && type.equals("first")) || (spin_result % 3 == 2  && type.equals("second")) || (spin_result % 3 == 0  && type.equals("third")));
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.WHITE);
        paint.setTextSize(56);
        canvas.drawRect(area,paint);

        canvas.rotate(90,area.centerX(), area.centerY());
        text = "2:1";
        paint.getTextBounds(text, 0,text.length(), textRect);
        canvas.drawText(text, area.centerX(), area.centerY() + textRect.height()/2, paint);
        canvas.rotate(-90,area.centerX(), area.centerY());
    }

}
