package com.guwop.roulette;

import android.content.Context;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class RouletteBoardSurface extends SurfaceView implements SurfaceHolder.Callback {

    private SurfaceHolder surfaceHolder;

    private RouletteThread rouletteThread;

    public RouletteBoardSurface(Context context){
        super(context);

        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);

        rouletteThread = new RouletteThread(surfaceHolder,context);

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // start the thread here so that we don't busy-wait in run()
        // waiting for the surface to be created

        rouletteThread.setRunning(true);
        rouletteThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        rouletteThread.setSurfaceSize(width,height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;

        rouletteThread.setRunning(false);

        while (retry) {
            try {
                rouletteThread.join();
                retry = false;

            } catch (InterruptedException e) {

            }
        }
    }

    public RouletteThread getThread() {
        return rouletteThread;
    }
}

