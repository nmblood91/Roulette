package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Split extends Bet{

    private float target1;
    private float target2;

    public Split(float t1_in, float t2_in, RectF area){
        target1=t1_in;
        target2=t2_in;
        payout = 17;
        this.area=area;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return target1 == spin_result || target2 == spin_result;
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {
        return;
    }
}