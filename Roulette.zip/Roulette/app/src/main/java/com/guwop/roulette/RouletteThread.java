package com.guwop.roulette;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.util.ArrayList;
import java.util.Random;


public class RouletteThread extends Thread {

    public static final int BET_MODE = 700;
    public static final int PRE_SPIN = 701;
    public static final int SPIN = 702;
    public static final int POST_SPIN = 703;
    public static final int INSIGHT = 704;
    public static final int POTENTIAL_WALK_AWAY = 705;
    public static final int GAME_OVER = 706;

    /** Handle to the surface manager object we interact with */
    private SurfaceHolder surfaceHolder;

    /** Handle to the application context, used to e.g. fetch Drawables. */
    private Context context;

    private boolean isInitialized;
    private boolean isRunning;
    private int gameState;

    private Paint paint;
    private int height;
    private int width;

    private ArrayList<Split> split_bets;
    private Street[] street_bets;
    private ArrayList<Square> square_bets;
    private ArrayList<Bet> all_bet_list;
    private ArrayList<Bet> player_bet_list;

    private Bitmap wheel;
    private long show_wheel_start_time;
    private float wheel_rotation_deg;
    private float wheel_rotation_speed;
    private Matrix wheelMatrix;
    private boolean wheelAnimationOver;

    private Bitmap ball;
    private float ball_rotation_deg;
    private Matrix ballMatrix;
    private boolean ballAnimationOver;
    private boolean spinAnimationOver;
    private long show_result_start_time;

    private long pitboss_start_time;

    private Bitmap brain;

    private Rect textRect;
    private String text;

    private RectF bet_area;
    private RectF numbers_area;
    private RectF zeroes_area;
    private RectF columns_area;
    private RectF dozens_area;
    private RectF outsidebet_area;

    private RectF chip_area;
    private Chip[] base_chips;
    private Chip free_chip;
    private Chip glorious_chip;
    private Bitmap poof;
    private boolean do_draw_poof;

    private RectF spin_button;
    private RectF balance_box;
    private RectF brain_box;
    private RectF insight_area;
    private RectF last_five_area;

    private RectF quit_area;
    private Bitmap door_icon;
    private WalkOut walkOutmenu;

    private ArrayList<Integer> tracker;
    private ArrayList<String> last5;

    private int balance;

    private int roll;

    private Random randy;
    private boolean pitbossAnimationOver;
    private Insight insight;
    private RectF quit_menu;


    public RouletteThread(SurfaceHolder surfaceHolder_in, Context context_in) {

        context = context_in;
        surfaceHolder = surfaceHolder_in;

        paint = new Paint();

        textRect = new Rect();

        paint.setAntiAlias(true);
        paint.setDither(true);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4);

        paint.setTextSize(72);
        paint.setTextAlign(Paint.Align.CENTER);

        paint.setAntiAlias(true);

        isInitialized = false;
        pitbossAnimationOver = true;

        randy = new Random(System.currentTimeMillis());

    }

    public void setSurfaceSize(int w, int h) {
        // synchronized to make sure these all change atomically
        synchronized (surfaceHolder) {
            width = w;
            height = h;
        }
    }

    public void setRunning(boolean b) {
        synchronized (surfaceHolder) {
            isRunning = b;
        }
    }

    public void initializeBoard (){

        Straight[][] straight_bets;
        Straight[]  zeroes_bets;
        Dozen[] dozens_bets;
        Column[] column_bets;
        Red_Black[] red_black_bets;
        Odd_Even[] odd_even_bets;
        High_Low[] high_low_bets;


        straight_bets = new Straight[3][12];
        zeroes_bets = new Straight[2];
        dozens_bets = new Dozen[3];
        column_bets = new Column[3];
        red_black_bets = new Red_Black[2];
        odd_even_bets = new Odd_Even[2];
        high_low_bets = new High_Low[2];
        split_bets = new ArrayList<Split>();
        street_bets = new Street[12];
        square_bets = new ArrayList<Square>();

        bet_area = new RectF(width*.25f, height*.02f,width*.98f,height*.98f);

        //zeroes area
        zeroes_area = new RectF(bet_area.left + (1/5f)* bet_area.width(), bet_area.top, bet_area.left + (4/5f)* bet_area.width(), bet_area.top + (1/14f)*bet_area.height());
        zeroes_bets[0] = new Straight(37,
                            new RectF( zeroes_area.centerX(),
                                    zeroes_area.top, zeroes_area.right, zeroes_area.bottom));

        zeroes_bets[1] = new Straight(38,
                        new RectF( zeroes_area.left,
                        zeroes_area.top, zeroes_area.centerX(), zeroes_area.bottom));


        //dozens area
        dozens_area = new RectF(bet_area.left +  (4/5f)* bet_area.width(), bet_area.top + (1/14f)*bet_area.height(), bet_area.right, bet_area.top + (13/14f)*bet_area.height());
        dozens_bets[0] = new Dozen("1st",
                                    new RectF( dozens_area.left, dozens_area.top,dozens_area.right, dozens_area.top + (1/3f)*dozens_area.height()));

        dozens_bets[1] = new Dozen("2nd",
                new RectF( dozens_area.left, dozens_area.top + (1/3f)*dozens_area.height(),dozens_area.right, dozens_area.top + (2/3f)*dozens_area.height()));

        dozens_bets[2] = new Dozen("3rd",
                new RectF( dozens_area.left, dozens_area.top + (2/3f)*dozens_area.height(),dozens_area.right, dozens_area.bottom));

        //columns area
        columns_area = new RectF(bet_area.left + (1/5f)* bet_area.width(), bet_area.top + (13/14f)*bet_area.height(), bet_area.left + (4/5f)* bet_area.width(), bet_area.top + (14/14f)*bet_area.height());
        column_bets[0] = new Column("first",
                new RectF( columns_area.left, columns_area.top, columns_area.left + (1/3f)*columns_area.width(), columns_area.bottom));

        column_bets[1] = new Column("second",
                new RectF(columns_area.left + (1/3f)*columns_area.width(), columns_area.top, columns_area.left + (2/3f)*columns_area.width(), columns_area.bottom));

        column_bets[2] = new Column("third",
                new RectF( columns_area.left + (2/3f)*columns_area.width(), columns_area.top, columns_area.right, columns_area.bottom));

        //outside bet area
        outsidebet_area = new RectF(bet_area.left , bet_area.top + (1/14f)*bet_area.height(), bet_area.left + (1/5f)* bet_area.width(), bet_area.top + (13/14f)*bet_area.height());

        high_low_bets[0] = new High_Low("1-18",
                                        new RectF( outsidebet_area.left, outsidebet_area.top,  outsidebet_area.right, outsidebet_area.top + (1/6f)*outsidebet_area.height()));

        odd_even_bets[0] = new Odd_Even("odd",
                new RectF(outsidebet_area.left, outsidebet_area.top + (1/6f)*outsidebet_area.height(),  outsidebet_area.right, outsidebet_area.top + (2/6f)*outsidebet_area.height()));

        red_black_bets[0] = new Red_Black("red",
                                        new RectF(outsidebet_area.left,outsidebet_area.top + (2/6f)*outsidebet_area.height(),  outsidebet_area.right, outsidebet_area.top + (3/6f)*outsidebet_area.height()));

        red_black_bets[1] = new Red_Black("black",
                new RectF(outsidebet_area.left, outsidebet_area.top + (3/6f)*outsidebet_area.height(), outsidebet_area.right, outsidebet_area.top + (4/6f)*outsidebet_area.height()));
        
        odd_even_bets[1] = new Odd_Even("even",
                new RectF(outsidebet_area.left,outsidebet_area.top + (4/6f)*outsidebet_area.height(),  outsidebet_area.right, outsidebet_area.top + (5/6f)*outsidebet_area.height()));

        high_low_bets[1] = new High_Low("19-36",
                new RectF( outsidebet_area.left, outsidebet_area.top+ (5/6f)*outsidebet_area.height(),  outsidebet_area.right, outsidebet_area.bottom ));


        //inner numbers
        numbers_area = new RectF(bet_area.left + (1/5f)* bet_area.width(), bet_area.top + (1/14f)*bet_area.height(), bet_area.left + (4/5f)* bet_area.width(), bet_area.top + (13/14f)*bet_area.height());
        
        float numbers_area_w = numbers_area.width();
        float numbers_area_h = numbers_area.height();

        for (int r=0; r<3; r++){
            for (int c = 0; c<12; c++){

                //create straight bets
                straight_bets[r][c] = new Straight((r+1 + c*3),
                        new RectF( numbers_area.left +r*numbers_area_w/3,
                                numbers_area.top + numbers_area_h*c/12,
                                numbers_area.left +numbers_area_w*(r+1)/3,
                                numbers_area.top + numbers_area_h*(c+1)/12));

                //temp_bitmap = Bitmap.createScaledBitmap(getNumberBitmap(r+1 + c*3), (int) numbers_area_h/12, (int) numbers_area_w/3, true );
                //straight_bets[r][c].setBitmap(temp_bitmap);

                //create split bets
                if (r<2) {
                    //vertical splits
                    split_bets.add(new Split(r+1 + c*3f, r+2 + c*3f,
                        new RectF(numbers_area.left + numbers_area_w*(r+1)/3 - .2f*numbers_area_w/3,
                                numbers_area.top + numbers_area_h*c/12,
                                numbers_area.left + numbers_area_w*(r+1)/3 + .2f*numbers_area_w/3,
                                numbers_area.top + numbers_area_h*(c+1)/12)));
                }

                if (c < 11){
                        //horizontal splits
                        split_bets.add(new Split(r+1 + c*3f, r+1 + (c+1)*3f,
                                new RectF(numbers_area.left + numbers_area_w*(r)/3,
                                          numbers_area.top + numbers_area_h*(c+1)/12 - .2f* numbers_area_h/12,
                                         numbers_area.left + numbers_area_w*(r+1)/3,
                                        numbers_area.top + numbers_area_h*(c+1)/12+ .2f* numbers_area_h/12)));
                    }

                    //create Street bets
                if (r==2)
                    street_bets[c] = new Street(c,
                            new RectF(numbers_area.right - .2f*numbers_area_w/3,
                                    numbers_area.top + numbers_area_h*c/12,
                                    numbers_area.right + .2f*numbers_area_w/3,
                                    numbers_area.top + numbers_area_h*(c+1)/12));

                //create square bets
                if(r<2 && c< 11) {
                    square_bets.add(new Square(r + 1 + c*3f,
                                               r + 2 + c*3f,
                                               r + 1 + (c+1)*3f,
                                               r + 2 + (c+1)*3f,
                                        new RectF( numbers_area.left + numbers_area_w*(r+1)/3 - .2f*numbers_area_w/3,
                                                numbers_area.top + numbers_area_h*(c+1)/12 - .2f*numbers_area_h/12,
                                                numbers_area.left + numbers_area_w*(r+1)/3 + .2f*numbers_area_w/3,
                                                numbers_area.top + numbers_area_h*(c+1)/12 + .2f*numbers_area_h/12
                                        )));
                    //as circle
                    /*square_bets.add(new Square(r + 1 + c*3f,
                            r + 2 + c*3f,
                            r + 1 + (c+1)*3f,
                            r + 2 + (c+1)*3f,
                            numbers_area.left + numbers_area_w*(r+1)/3,
                             numbers_area.top + numbers_area_h*(c+1)/12,
                            (float) Math.sqrt(Math.pow(.2f*numbers_area_w/3,2) + Math.pow(.2f* numbers_area_h/12,2))));
                        */


                }
            }
        }

        all_bet_list = new ArrayList<>();
        player_bet_list = new ArrayList<>();

        for (Square square: square_bets){
            all_bet_list.add(square);
        }

        for (int c = 0; c < 12; c++) {
            all_bet_list.add(street_bets[c]);
        }

        for (Split split: split_bets){
            all_bet_list.add(split);
        }

        for (int r=0; r<3; r++) {
            for (int c = 0; c < 12; c++) {
                all_bet_list.add(straight_bets[r][c]);
            }
        }

        for (int k=0; k<3; k++){

            //column
            all_bet_list.add(column_bets[k]);
            all_bet_list.add(dozens_bets[k]);

        }

        //lower outside bets and 0, 00
        for (int k=0; k<2; k++){

            //high low
            all_bet_list.add(high_low_bets[k]);

            //odd-even
            all_bet_list.add(odd_even_bets[k]);

            //red black
            all_bet_list.add(red_black_bets[k]);

            //zeroes
            all_bet_list.add(zeroes_bets[k]);
        }

        chip_area = new RectF(width*.04f, height*.74f, width*.22f, height*.98f);
        base_chips = new Chip[8];

        Bitmap chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip1);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[0] = new Chip(chip_area.centerX() + .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*1,1,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip2);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[1] = new Chip(chip_area.centerX() + .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*3,2,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip5);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[2] = new Chip(chip_area.centerX() + .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*5,5,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip10);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[3] = new Chip(chip_area.centerX() + .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*7,10,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip25);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[4] = new Chip(chip_area.centerX() - .25f*chip_area.width(),chip_area.top  + chip_area.height()*.125f*1,25,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip50);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[5] = new Chip(chip_area.centerX() - .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*3,50,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip75);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[6] = new Chip(chip_area.centerX() - .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*5,75,chip);

        chip = BitmapFactory.decodeResource(context.getResources(), R.drawable.chip100);
        chip = Bitmap.createScaledBitmap(chip,(int) (chip_area.width()*.48), (int)(chip_area.width()*.48), true);
        base_chips[7] = new Chip(chip_area.centerX() - .25f*chip_area.width(),chip_area.top + chip_area.height()*.125f*7,100,chip);

        free_chip = null;

        poof = BitmapFactory.decodeResource(context.getResources(), R.drawable.poof);
        poof = Bitmap.createScaledBitmap(poof,(int) (chip.getHeight()*1.5), (int)(chip.getHeight()*1.5*poof.getWidth()/poof.getHeight()), true);

        wheel = BitmapFactory.decodeResource(context.getResources(), R.drawable.wheel);
        wheel = Bitmap.createScaledBitmap(wheel,(int) (width*.97), (int)(width*.97), true);
        wheelMatrix = new Matrix();
        wheelAnimationOver = false;

        ball = BitmapFactory.decodeResource(context.getResources(), R.drawable.ball);
        ball = Bitmap.createScaledBitmap(ball,(int) (wheel.getHeight()*.06), (int)(wheel.getHeight()*.06), true);
        ballMatrix = new Matrix();
        ballAnimationOver = false;

        spin_button = new RectF(width*.04f,height*.02f, width*.22f, height*.16f );

        last_five_area = new RectF(width*.04f,height*.17f, width*.22f, height*.4f );
        last5 = new ArrayList<>();

        balance = 100;
        tracker = new ArrayList<>();
        tracker.add(Integer.valueOf(balance));
        balance_box = new RectF(width*.04f, height*.41f, width*.22f, height*.59f);

        brain_box = new RectF(width*.04f, height*.6f, width*.22f, height*.73f);
        brain = BitmapFactory.decodeResource(context.getResources(), R.drawable.brain);
        brain = Bitmap.createScaledBitmap(brain,(int) (brain_box.height()*.8), (int)(brain_box.width()*.8), true);

        insight_area = bet_area;

        quit_area = new RectF(columns_area.right, dozens_area.bottom,dozens_area.right,columns_area.bottom);
        door_icon = BitmapFactory.decodeResource(context.getResources(), R.drawable.door);
        door_icon = Bitmap.createScaledBitmap(door_icon,(int) (quit_area.height()*.85), (int)(quit_area.width()*.85), true);

        show_result_start_time = 0;

        gameState = BET_MODE;

        isInitialized = true;

        return;

    }



    public void drawBoard(Canvas canvas) {

        //background color
        canvas.drawColor(ContextCompat.getColor(context,R.color.tableGreen));

        if (false) {
            paint.setColor(Color.DKGRAY);
            for (int c = 0; c < 12; c++)
                canvas.drawRect(street_bets[c].area, paint);

            paint.setColor(Color.GRAY);
            for (Split split : split_bets) {
                canvas.drawRect(split.area, paint);
            }

            paint.setColor(Color.BLUE);
            paint.setStyle(Paint.Style.FILL);
            for (Square square : square_bets) {
                canvas.drawRect(square.area, paint);
            }

        }
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        
        canvas.drawRect(chip_area,paint);

        //draw spin button
        paint.setTextSize(68);
        canvas.drawRect(spin_button,paint);
        canvas.rotate(90,spin_button.centerX(),spin_button.centerY());
        text = "Spin";
        //paint.getTextBounds(text, 0,text.length(), textRect);
        canvas.drawText(text,spin_button.centerX(),spin_button.centerY() + textRect.height()/2f, paint);
        canvas.rotate(-90,spin_button.centerX(),spin_button.centerY());

        //draw last 5 area
        canvas.drawRect(last_five_area,paint);
        paint.setTextSize(25);
        paint.setStrokeWidth(2);

        canvas.rotate(90,last_five_area.centerX(),last_five_area.centerY());
        text = "Last 5 rolls:";
        paint.getTextBounds(text, 0,text.length(), textRect);
        canvas.drawText(text,last_five_area.left,last_five_area.centerY()+ textRect.height()/2f, paint);

        paint.setTextSize(23);
        paint.setStrokeWidth(2);

        if(last5.size()>0) {

            for (int x = 0; x < Math.min(5,last5.size()); x++) {
                text = last5.get(x);
                paint.getTextBounds(text, 0,text.length(), textRect);

                if(text.substring(0,1).equals("R"))
                    paint.setColor(Color.rgb(193,39,45));
                else if(text.substring(0,1).equals("B"))
                    paint.setColor(Color.BLACK);
                else
                    paint.setColor(Color.WHITE);

                canvas.drawText(text,last_five_area.centerX()+.25f*last_five_area.height(), last_five_area.centerY() - last_five_area.width()*.31f + (paint.descent() - paint.ascent())*x, paint);

            }
        }
        canvas.rotate(-90,last_five_area.centerX(),last_five_area.centerY());

        //draw balance box
        paint.setColor(Color.WHITE);
        paint.setTextSize(68);
        paint.setStrokeWidth(4);
        canvas.drawRect(balance_box,paint);
        canvas.rotate(90,balance_box.centerX(),balance_box.centerY());
        text = Integer.toString(balance);
        paint.getTextBounds(text, 0,text.length(), textRect);
        canvas.drawText(text ,balance_box.centerX(),balance_box.centerY()+ textRect.height()/2f, paint);
        canvas.rotate(-90,balance_box.centerX(),balance_box.centerY());

        //draw brain box
        canvas.drawRect(brain_box,paint);
        canvas.rotate(90,brain_box.centerX(), brain_box.centerY());
        canvas.drawBitmap(brain, brain_box.centerX() - brain.getWidth()/2f,brain_box.centerY() - brain.getHeight()/2f,paint);
        canvas.rotate(-90,brain_box.centerX(), brain_box.centerY());

        //draw door_icon
        canvas.rotate(90,quit_area.centerX(), quit_area.centerY());
        canvas.drawBitmap(door_icon, quit_area.centerX() - door_icon.getWidth()*.45f,quit_area.centerY() - door_icon.getHeight()*.5f ,paint);
        canvas.rotate(-90,quit_area.centerX(), quit_area.centerY());

        //draw base chips
        for (int x = 0; x<8; x++)
            if (balance >= base_chips[x].getValue())
                base_chips[x].drawChip(canvas,paint);

        //draw bets
        for(Bet b: all_bet_list) {
            b.drawBetArea(canvas, paint, textRect);
                    }

        //draw chips
        for(Bet b: all_bet_list) {
            if(b.hasChip())
                b.drawChip(canvas,paint);
        }

        //draw free chip
        if (free_chip!=null)
            free_chip.drawChip(canvas,paint);

        //draw glorious chip
        if (glorious_chip!=null)
            glorious_chip.drawChip(canvas,paint);

        return;
    }

    public void run(){

        while(isRunning) {
            if (isInitialized == false && width > 0)
                initializeBoard();
            else if (isInitialized) {

                Canvas c = null;

                try {
                    c = surfaceHolder.lockCanvas(null);

                    drawBoard(c);

                    if (gameState == BET_MODE){

                    }else if (gameState == PRE_SPIN){
                        collect_bets();
                        doRoll();
                        gameState = SPIN;
                        show_wheel_start_time = System.currentTimeMillis();
                        spinAnimationOver=false;
                        wheelAnimationOver=false;
                        ballAnimationOver=false;
                        do_draw_poof = false;
                    }else if(gameState == SPIN){
                        if(!spinAnimationOver)
                            drawWheel(c);
                        else{
                            updateChips();
                            pitboss_start_time = System.currentTimeMillis();
                            pitbossAnimationOver = false;
                            gameState = POST_SPIN;
                        }
                    }else if(gameState == POST_SPIN){

                        if(!pitbossAnimationOver)
                        drawPitboss(c);
                        else {

                            tracker.add(balance);
                            last5.add(0, rollToString(roll));

                            if (balance == 0) {
                                gameState = GAME_OVER;
                                walkOutmenu = new WalkOut(height, width, WalkOut.BUST, tracker);
                            } else {
                                resetBets();
                                gameState = BET_MODE;

                            }
                        }

                    }else if(gameState == INSIGHT){
                        insight.drawInsight(c,paint);
                    }
                    else if(gameState == POTENTIAL_WALK_AWAY || gameState == GAME_OVER){
                        walkOutmenu.drawWalkOut(c,paint);
                    }
                } finally {
                    // do this in a finally so that if an exception is thrown
                    // during the above, we don't leave the Surface in an
                    // inconsistent state
                    if (c != null) {
                        surfaceHolder.unlockCanvasAndPost(c);
                    }
                }// end finally block

            }
        }
    }



    private void resetBets() {

        player_bet_list.clear();

        for (Bet b: all_bet_list)
            b.setChip(null);
    }

    private void collect_bets() {

        player_bet_list.clear();

        for (Bet b: all_bet_list)
            if (b.hasChip())
                player_bet_list.add(b);

        return;
    }

    private void doRoll() {
        roll = randy.nextInt(38) + 1;
    }

    private void drawWheel(Canvas c) {

        //put into whole seconds
        float elapsed_time = (System.currentTimeMillis() - show_wheel_start_time)/1000f;

        //draw wheel
        wheelMatrix.reset();

        if (elapsed_time < 1){
            wheel_rotation_deg = 90;
            //Log.d("TAGG", "target:" + show_wheel_start_time % 360);
        }
        else if (elapsed_time < 6) {
            wheel_rotation_speed = (float) Math.max((-1 *Math.sqrt(elapsed_time - 1) + 3.2),0);
            wheel_rotation_speed *= 12;
            Log.d("TAGG", "speed1: " + wheel_rotation_speed);
            wheel_rotation_deg += ((elapsed_time - 1) / 10f) * wheel_rotation_speed;
            //Log.d("TAGG", "deg: " + wheel_rotation_deg % 360);
        }else if(wheelAnimationOver == false) {

            if ((wheel_rotation_speed <= 2 && Math.abs(show_wheel_start_time % 180 - wheel_rotation_deg % 180) < 10)){
               // Log.d("TAGG", "made it:" + show_wheel_start_time % 360);
                wheel_rotation_speed = 0;
                wheelAnimationOver = true;
            }else {
                wheel_rotation_speed -= ((elapsed_time - 6) / 20f);
                wheel_rotation_speed = Math.max(wheel_rotation_speed,2);
                wheel_rotation_deg += ((elapsed_time - 1) / 10f) * wheel_rotation_speed;
                Log.d("TAGG", "speed2: " + wheel_rotation_speed);
            }

        }


        //Log.d("TAGG", "deg: " + wheel_rotation_deg % 360);


        wheelMatrix.postRotate(wheel_rotation_deg, wheel.getWidth()/2f, wheel.getWidth()/2f);
        wheelMatrix.postTranslate(width/2f - wheel.getWidth()/2f , height/2f - wheel.getHeight()/2f);

        c.drawBitmap(wheel,wheelMatrix,paint);

        ballMatrix.reset();

        if (elapsed_time <2){
            ball_rotation_deg = 90;
        }else if(wheelAnimationOver == false){
            ball_rotation_deg = 90 - 5*(elapsed_time-2)/16f*360;
        }else if(wheelAnimationOver == true && ballAnimationOver == false){

            float ball_closeness = Math.abs((ball_rotation_deg % 360)+360 - ((degOffset(roll) + wheel_rotation_deg) % 360));
            Log.d("BC", "ball closeness " + ball_closeness);

            if (ball_closeness > 10 && ball_closeness < 350 ){
                ball_rotation_deg = 90 - 5*(elapsed_time-2)/16f*360;
            } else {
                ball_rotation_deg = (degOffset(roll) + wheel_rotation_deg);
                ballAnimationOver = true;
                show_result_start_time = System.currentTimeMillis();
            }

        }

        ballMatrix.postTranslate(width/2f - ball.getWidth()/2 + (float)(Math.sin(Math.toRadians(ball_rotation_deg))*.467*wheel.getWidth()),
                                 height/2f - ball.getHeight()/2f - (float)(Math.cos(Math.toRadians(ball_rotation_deg))*.467*wheel.getHeight()));
        c.drawBitmap(ball,ballMatrix,paint);


        if (System.currentTimeMillis() - show_result_start_time < 5000){

        }else if(wheelAnimationOver && ballAnimationOver) {
            spinAnimationOver = true;
        }


    }

    private void updateChips(){

        for (Bet b: player_bet_list) {
            if (b.did_win(roll)) {
                b.getChip().makeGlorious();
            } else {
                do_draw_poof = true;
            }
        }
    }

    private void drawPitboss(Canvas c) {

        float elapsed_time = (System.currentTimeMillis() - pitboss_start_time)/1000f;
        boolean stillGlorious = false;

        if (elapsed_time < 4 && do_draw_poof) {
            double poof_stretch = Math.abs( Math.sin(elapsed_time/8f * (2 * 3.1415)));
            poof_stretch *= poof.getHeight();

            for (Bet b : player_bet_list) {
                if (!b.getChip().isGlorious()) {

                    if(poof_stretch> 10){
                        Log.d("poof", "poof: " + poof_stretch);
                        Bitmap image = Bitmap.createScaledBitmap(poof, (int) (poof_stretch) + 1, (int) (poof_stretch) + 1, true);
                        c.rotate(90,b.area.centerX(), b.area.centerY());
                        c.drawBitmap(image, b.area.centerX() - image.getHeight()/2, b.area.centerY() - image.getHeight()/2,paint);
                        c.rotate(-90,b.area.centerX(), b.area.centerY());
                    }

                    if(elapsed_time > 1.5) {
                        b.getChip().setImage(null);
                    }
                }
            }
        }
        else {//either past 4 seconds or no poofs, draw winning chips

            for (Bet b : player_bet_list) {
                if (b.getChip().isGlorious()) {

                    stillGlorious = true;
                    float speed = 6;

                    if(b.getChip().goToHeaven(balance_box, speed))
                        balance += b.getChip().getValue() * (1 + b.getPayout());

                    //used for drawing the board so it will always be on top
                    glorious_chip = b.getChip();

                    break;
                }
            }

            if (stillGlorious == false)
                pitbossAnimationOver = true;

        }
    }


    public boolean handleBetModeTouchEvent(MotionEvent event) {

        float x = event.getX();
        float y = event.getY();

        if (event.getAction() == MotionEvent.ACTION_DOWN && spin_button.contains(x,y))
        {
            if (free_chip != null)
                balance += free_chip.getValue();

            free_chip=null;
            gameState = PRE_SPIN;
        }

        if (event.getAction() == MotionEvent.ACTION_DOWN && brain_box.contains(x,y))
        {
            collect_bets();

            if (!player_bet_list.isEmpty()) {
                insight = new Insight(insight_area, player_bet_list);
                gameState = INSIGHT;
            }
        }

        if (event.getAction() == MotionEvent.ACTION_DOWN && quit_area.contains(x,y) && tracker.size()>1)
        {
            walkOutmenu = new WalkOut(height,width,WalkOut.WALK_OUT,tracker);
            gameState = POTENTIAL_WALK_AWAY;
        }

        if (event.getAction() == MotionEvent.ACTION_DOWN && free_chip == null){

            //see if new chip is trying ot be picked
            if (chip_area.contains(x,y)) {
                for (int c = 0; c < 8; c++) {
                    if (base_chips[c].contains(x, y) && balance >= base_chips[c].getValue()) {
                        free_chip = new Chip(base_chips[c]);
                        balance -= free_chip.getValue();
                        return true;
                    }
                }
            }

            //see if chip is trying to be deselected
            if (bet_area.contains(x,y)) {
                for (Bet b : all_bet_list) {
                    if (b.hasChip() && b.getChip().contains(x, y)) {
                        free_chip = b.getChip();
                        b.setChip(null);
                        return true;
                    }
                }
            }

        }else if(event.getAction() == MotionEvent.ACTION_MOVE && free_chip !=null){ //moving the chip

            free_chip.setCoords(x,y);

        }else if(event.getAction() == MotionEvent.ACTION_UP && free_chip !=null) {

            //check to see if it can be placed
            for (Bet b : all_bet_list) {

                if (!b.hasChip() && b.contains(x, y)) {
                    free_chip.setCoords(b.area.centerX(), b.area.centerY());
                    b.setChip(free_chip);

                    free_chip = null;
                    return true;
                }

            }

            //if no where to go return chip to base area
            balance += free_chip.getValue();
            free_chip = null;
            return true;

        }

        return true;
    }

    public boolean handleInsightModeTouchEvent(MotionEvent event) {

        float x = event.getX();
        float y = event.getY();

        if(!insight_area.contains(x,y) && event.getAction() == MotionEvent.ACTION_DOWN)
            gameState = BET_MODE;

        return true;
    }


    public int getGameState() {
        return gameState;
    }

    public int handleWalkOutModeTouchEvent(MotionEvent event) {

        int return_val = -1;

        if (event.getAction() != MotionEvent.ACTION_DOWN)
            return -1;

        switch(walkOutmenu.handleTouchEvent(event)){

            case WalkOut.RETURN_TO_BOARD:
                gameState = BET_MODE;
                walkOutmenu = null;
                return_val= WalkOut.RETURN_TO_BOARD;
                break;

            case WalkOut.END_GAME:
                return_val = WalkOut.END_GAME;
                break;
        }

        return return_val;
    }


    public int handleGameOverTouchEvent(MotionEvent event) {

        if (event.getAction() != MotionEvent.ACTION_DOWN)
            return -1;

        return walkOutmenu.handleTouchEvent(event);
    }

    private float degOffset(int spin_result){

        int offset = -1;

        switch(spin_result) {
            case 1:
                offset =20;
                break;
            case 2:
                offset =1;
                break;
            case 3:
                offset =24;
                break;
            case 4:
                offset =5;
                break;
            case 5:
                offset =28;
                break;
            case 6:
                offset =9;
                break;
            case 7:
                offset =32;
                break;
            case 8:
                offset =13;
                break;
            case 9:
                offset =36;
                break;
            case 10:
                offset =17;
                break;
            case 11:
                offset =33;
                break;
            case 12:
                offset =14;
                break;
            case 13:
                offset =21;
                break;
            case 14:
                offset = 2;
                break;
            case 15:
                offset =25;
                break;
            case 16:
                offset =6;
                break;
            case 17:
                offset =29;
                break;
            case 18:
                offset =10;
                break;
            case 19:
                offset =12;
                break;
            case 20:
                offset =31;
                break;
            case 21:
                offset =8;
                break;
            case 22:
                offset =27;
                break;
            case 23:
                offset =4;
                break;
            case 24:
                offset =23;
                break;
            case 25:
                offset =16;
                break;
            case 26:
                offset =35;
                break;
            case 27:
                offset =18;
                break;
            case 28:
                offset =37;
                break;
            case 29:
                offset =15;
                break;
            case 30:
                offset =34;
                break;
            case 31:
                offset =11;
                break;
            case 32:
                offset =30;
                break;
            case 33:
                offset =7;
                break;
            case 34:
                offset =26;
                break;
            case 35:
                offset =3;
                break;
            case 36:
                offset =22;
                break;
            case 37:
                offset = 0;
                break;
            case 38:
                offset = 19;
                break;
            default:

                break;
        }

        return offset*9.4736f;


    }

    private String rollToString(int spin_result){

        String str;

        switch(spin_result) {
            case 1:
                str = "Red " + spin_result;
                break;
            case 2:
                str = "Black " + spin_result;
                break;
            case 3:
                str = "Red " + spin_result;
                break;
            case 4:
                str = "Black " + spin_result;
                break;
            case 5:
                str = "Red " + spin_result;
                break;
            case 6:
                str = "Black " + spin_result;
                break;
            case 7:
                str = "Red " + spin_result;
                break;
            case 8:
                str = "Black " + spin_result;
                break;
            case 9:
                str = "Red " + spin_result;
                break;
            case 10:
                str = "Black " + spin_result;
                break;
            case 11:
                str = "Black " + spin_result;
                break;
            case 12:
                str = "Red " + spin_result;
                break;
            case 13:
                str = "Black " + spin_result;
                break;
            case 14:
                str = "Red " + spin_result;
                break;
            case 15:
                str = "Black " + spin_result;
                break;
            case 16:
                str = "Red " + spin_result;
                break;
            case 17:
                str = "Black " + spin_result;
                break;
            case 18:
                str = "Red " + spin_result;
                break;
            case 19:
                str = "Red " + spin_result;
                break;
            case 20:
                str = "Black " + spin_result;
                break;
            case 21:
                str = "Red " + spin_result;
                break;
            case 22:
                str = "Black " + spin_result;
                break;
            case 23:
                str = "Red " + spin_result;
                break;
            case 24:
                str = "Black " + spin_result;
                break;
            case 25:
                str = "Red " + spin_result;
                break;
            case 26:
                str = "Black " + spin_result;
                break;
            case 27:
                str = "Red " + spin_result;
                break;
            case 28:
                str = "Black " + spin_result;
                break;
            case 29:
                str = "Black " + spin_result;
                break;
            case 30:
                str = "Red " + spin_result;
                break;
            case 31:
                str = "Black " + spin_result;
                break;
            case 32:
                str = "Red " + spin_result;
                break;
            case 33:
                str = "Black " + spin_result;
                break;
            case 34:
                str = "Red " + spin_result;
                break;
            case 35:
                str = "Black " + spin_result;
                break;
            case 36:
                str = "Red " + spin_result;
                break;
            case 37:
                str = "Green 0";
                break;
            case 38:
                str = "Green 00";
                break;
            default:
                str = "FXX";
                break;


        }

        return str;
    }

}
