package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Dozen extends Bet {

    String type;

    public Dozen(String type, RectF area){
        this.area=area;
        this.type = type+ " 12";
        payout = 2;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return spin_result <= 36 && ( ((spin_result-1) / 12 == 0  && type.equals("1st 12")) || ((spin_result-1) /12 == 1  && type.equals("2nd 12")) || ((spin_result-1)/12 == 2  && type.equals("3rd 12")));
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.WHITE);
        paint.setTextSize(68);

        canvas.drawRect(area,paint);

        canvas.rotate(90,area.centerX(), area.centerY());
        paint.getTextBounds(type, 0,type.length(), textRect);
        canvas.drawText(type, area.centerX(), area.centerY() + textRect.height()/2f, paint);
        canvas.rotate(-90,area.centerX(), area.centerY());

        }
    }

