package com.guwop.roulette;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Chip {

    private Bitmap image;
    private int value;
    private float x;
    private float y;
    private float radius;
    private boolean isGlorious;


    public Chip (float x, float y, int value, Bitmap image){
        this.x=x;
        this.y=y;
        this.radius=image.getHeight()/2f;
        this.value=value;
        this.image = image;
        isGlorious = false;
    }

    public Chip(Chip toCopy) {
        this.x=toCopy.x;
        this.y=toCopy.y;
        this.radius=toCopy.radius;
        this.value=toCopy.value;
        this.image = toCopy.image;
    }

    public void drawChip(Canvas c, Paint p){

        if (image==null)
            return;

        c.rotate(90,x, y);

        if (isGlorious) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.YELLOW);
            p.setAlpha(200);
            c.drawCircle(x, y, image.getHeight() * .8f, p);
            p.setAlpha(255);
        }

        c.drawBitmap(image, x - image.getHeight()/2, y - image.getHeight()/2,p);

        c.rotate(-90,x, y);

    }

    public boolean contains(float x, float y){
        return radius >= Math.sqrt((this.x-x)*(this.x-x) + (this.y-y)*(this.y-y));
    }

    public void setCoords(float x, float y){
        this.x=x;
        this.y=y;
    }

    public void setImage(Bitmap b){
        image=b;
    }

    public int getValue() {
        return value;
    }

    public void makeGlorious() {
        isGlorious=true;
    }

    public boolean isGlorious() { return image!=null && isGlorious; }

    public boolean goToHeaven(RectF balance_box, float speed) {

        if (x-balance_box.centerX() < 10 && y-balance_box.centerY() <10 ) {
            image = null;
            isGlorious = false;
            return true;
        }
        else {
            double angle = Math.atan2((1.0) * (y - balance_box.centerY()), (1.0) * (x - balance_box.centerX()));
            y -= speed * Math.sin(angle);
            x -= speed * Math.cos(angle);
            return false;
        }

    }
}
