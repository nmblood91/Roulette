package com.guwop.roulette;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

public class FreePlayActivity extends Activity implements View.OnTouchListener {

    private RouletteThread rouletteThread;
    private RouletteBoardSurface rouletteBoardSurface;

    private Handler thread_handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rouletteBoardSurface = new RouletteBoardSurface(this);
        rouletteBoardSurface.setOnTouchListener(this);
        setContentView(rouletteBoardSurface);

        rouletteThread = rouletteBoardSurface.getThread();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        switch(rouletteThread.getGameState()){
            case RouletteThread.BET_MODE:
                return rouletteThread.handleBetModeTouchEvent(event);
            case RouletteThread.INSIGHT:
                return rouletteThread.handleInsightModeTouchEvent(event);
            case RouletteThread.POTENTIAL_WALK_AWAY:
                 if (rouletteThread.handleWalkOutModeTouchEvent(event) == WalkOut.END_GAME)
                     onBackPressed();
                 return true;
            case RouletteThread.GAME_OVER:
                 if(rouletteThread.handleGameOverTouchEvent(event) == WalkOut.END_GAME)
                     onBackPressed();
                 return true;
            default:
                return true;
        }
    }

    @Override
    public void onBackPressed() {
        boolean retry = true;

        rouletteThread.setRunning(false);

        while (retry) {
            try {
                rouletteThread.join();
                retry = false;

            } catch (InterruptedException e) {
            }
        }
        finish();
    }

}
