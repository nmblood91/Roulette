package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Street extends Bet{

    private float row;

    public Street(float row_in, RectF area){
        row=row_in;
        payout = 11;
        this.area = area;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return (spin_result <= (row+1) *3) && (spin_result > row*3);
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {
        return;
    }
}