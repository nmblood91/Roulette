package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Odd_Even extends Bet{

    String type;

    public Odd_Even(String type, RectF area){
        this.area=area;
        this.type = type;
        payout = 1;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return spin_result <= 36 && ( (spin_result % 2 == 0  && type.equals("even")) || (spin_result % 2 == 1  && type.equals("odd")));
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {
        paint.setTextSize(62);
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);

        canvas.drawRect(area,paint);

        canvas.rotate(90,area.centerX(), area.centerY());

        paint.getTextBounds(type, 0,type.length(), textRect);
        canvas.drawText(type, area.centerX(), area.centerY() + textRect.height()/2f, paint);
        canvas.rotate(-90,area.centerX(), area.centerY());


    }
}
