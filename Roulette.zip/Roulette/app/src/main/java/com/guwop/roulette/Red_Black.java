package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Red_Black extends Bet {

    String color;

    public Red_Black(String color, RectF area){
        this.area=area;
        this.color=color;
        payout = 1;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return color.equals(redOrBlack(spin_result));
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.WHITE);
        canvas.drawRect(area,paint);


        paint.setTextSize(62);
        if (color.equals("red"))
            paint.setColor(Color.rgb(193,39,45));
        else
            paint.setColor(Color.BLACK);

        canvas.rotate(90,area.centerX(), area.centerY());
        paint.getTextBounds(color, 0,color.length(), textRect);
        canvas.drawText(color, area.centerX(), area.centerY() + textRect.height()/2f , paint);

        canvas.rotate(-90,area.centerX(), area.centerY());

    }

    public String redOrBlack(int spin_result){

        String c;

        switch(spin_result) {
            case 1:
                c = "red";
                break;
            case 2:
                c = "black";
                break;
            case 3:
                c = "red";
                break;
            case 4:
                c = "black";
                break;
            case 5:
                c = "red";
                break;
            case 6:
                c = "black";
                break;
            case 7:
                c = "red";
                break;
            case 8:
                c = "black";
                break;
            case 9:
                c = "red";
                break;
            case 10:
                c = "black";
                break;
            case 11:
                c = "black";
                break;
            case 12:
                c = "red";
                break;
            case 13:
                c = "black";
                break;
            case 14:
                c = "red";
                break;
            case 15:
                c = "black";
                break;
            case 16:
                c = "red";
                break;
            case 17:
                c = "black";
                break;
            case 18:
                c = "red";
                break;
            case 19:
                c = "red";
                break;
            case 20:
                c = "black";
                break;
            case 21:
                c = "red";
                break;
            case 22:
                c = "black";
                break;
            case 23:
                c = "red";
                break;
            case 24:
                c = "black";
                break;
            case 25:
                c = "red";
                break;
            case 26:
                c = "black";
                break;
            case 27:
                c = "red";
                break;
            case 28:
                c = "black";
                break;
            case 29:
                c = "black";
                break;
            case 30:
                c = "red";
                break;
            case 31:
                c = "black";
                break;
            case 32:
                c = "red";
                break;
            case 33:
                c = "black";
                break;
            case 34:
                c = "red";
                break;
            case 35:
                c = "black";
                break;
            case 36:
                c = "red";
                break;
            default:
                c = "green";
                break;
        }

        return c;


    }


}


