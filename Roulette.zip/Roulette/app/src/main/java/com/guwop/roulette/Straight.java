package com.guwop.roulette;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Straight extends Bet {

    private int target;
    private int color;
    private String text;

    public Straight(int target_in, RectF area){
        target=target_in;
        payout = 35;
        this.area = area;
        chip = null;
        
        setColor(target_in);

    }

    private void setColor(int target_in) {
        
        switch (target_in) {
            case 1:
                color = Color.rgb(193,39,45);
                break;
            case 2:
                color = Color.BLACK;
                break;
            case 3:
                color = Color.rgb(193,39,45);
                break;
            case 4:
                color = Color.BLACK;
                break;
            case 5:
                color = Color.rgb(193,39,45);
                break;
            case 6:
                color = Color.BLACK;
                break;
            case 7:
                color = Color.rgb(193,39,45);
                break;
            case 8:
                color = Color.BLACK;
                break;
            case 9:
                color = Color.rgb(193,39,45);
                break;
            case 10:
                color = Color.BLACK;
                break;
            case 11:
                color = Color.BLACK;
                break;
            case 12:
                color = Color.rgb(193,39,45);
                break;
            case 13:
                color = Color.BLACK;
                break;
            case 14:
                color = Color.rgb(193,39,45);
                break;
            case 15:
                color = Color.BLACK;
                break;
            case 16:
                color = Color.rgb(193,39,45);
                break;
            case 17:
                color = Color.BLACK;
                break;
            case 18:
                color = Color.rgb(193,39,45);
                break;
            case 19:
                color = Color.rgb(193,39,45);
                break;
            case 20:
                color = Color.BLACK;
                break;
            case 21:
                color = Color.rgb(193,39,45);
                break;
            case 22:
                color = Color.BLACK;
                break;
            case 23:
                color = Color.rgb(193,39,45);
                break;
            case 24:
                color = Color.BLACK;
                break;
            case 25:
                color = Color.rgb(193,39,45);
                break;
            case 26:
                color = Color.BLACK;
                break;
            case 27:
                color = Color.rgb(193,39,45);
                break;
            case 28:
                color = Color.BLACK;
                break;
            case 29:
                color = Color.BLACK;
                break;
            case 30:
                color = Color.rgb(193,39,45);
                break;
            case 31:
                color = Color.BLACK;
                break;
            case 32:
                color = Color.rgb(193,39,45);
                break;
            case 33:
                color = Color.BLACK;
                break;
            case 34:
                color = Color.rgb(193,39,45);
                break;
            case 35:
                color = Color.BLACK;
                break;
            case 36:
                color = Color.rgb(193,39,45);
                break;
            default:
                color = Color.WHITE;
                break;
        }

        return;
    }


    @Override
    public boolean did_win(int spin_result) {
        return target == spin_result;
    }

    @Override
    public boolean contains(float x, float y) {
        return area.contains(x,y);
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {

        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setTextSize(68);
        canvas.drawRect(area, paint);

        paint.setColor(color);

        canvas.rotate(90,area.centerX(), area.centerY());

        if (target<=36)
        text = String.valueOf(target);
        else if(target==37)
            text = "0";
        else
            text = "00";

        paint.getTextBounds(text, 0,text.length(), textRect);
        canvas.drawText(text, area.centerX() , area.centerY() + textRect.height()/2,paint);

        canvas.rotate(-90,area.centerX(), area.centerY());

    }

}