package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;

import java.util.ArrayList;

public class WalkOut {

    public static final int WALK_OUT = 801;
    public static final int BUST = 802;

    public static final int RETURN_TO_BOARD = 803;
    public static final int END_GAME = 804;


    private int type;
    private RectF background;
    private RectF graph;
    private RectF end_game;
    private RectF continue_game;
    private RectF summary;
    private ArrayList<Integer> game_stats;
    private int ath_turn;
    private float ath_amount;
    private float atl_amount;
    private int turns;
    private float x_axis_height;
    private Rect textRect;
    private String text;

    public WalkOut(int height, int width, int type, ArrayList<Integer> game_stats){

        background= new RectF(0,0,width,height);

        graph = new RectF(width*.25f,height*.05f,width*.95f,height*.95f);

        summary = new RectF(width*.04f,height*.05f, width*.22f, height*.5f);

        continue_game = new RectF(width*.04f,height*.53f, width*.22f, height*.73f);
        end_game = new RectF(width*.04f,height*.75f, width*.22f, height*.95f);



        this.game_stats = game_stats;
        this.type = type;

        ath_amount = -1;
        ath_turn = -1;
        atl_amount= game_stats.get(0);

        textRect=new Rect();

        turns=game_stats.size();

        //find high and low
        for (int x=0; x<turns;x++){

            if(game_stats.get(x) >= ath_amount){
                ath_amount= game_stats.get(x);
                ath_turn= x+1;
            }

            if(game_stats.get(x) <= atl_amount){
                atl_amount= game_stats.get(x);
            }


        }

        x_axis_height = (game_stats.get(0)/ath_amount) * graph.width();


    }


    public void drawWalkOut(Canvas c, Paint p){

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        c.drawRect(background,p);

        p.setStyle(Paint.Style.FILL_AND_STROKE);

        //draw graph
        p.setColor(Color.LTGRAY);
        c.drawRect(graph,p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.GRAY);
        for(float x=0; x<27; x+=2){
            c.drawLine(graph.left + x_axis_height, graph.top +x/27f*graph.height(), graph.left + x_axis_height, graph.top +(x+1)/27f*graph.height(), p);
        }

        p.setColor(Color.BLACK);
        for(int x = 0; x< turns-1; x++){

            c.drawLine(graph.left + game_stats.get(x)/ath_amount*graph.width(), graph.top + x/(1f*turns-1)*graph.height(), graph.left + game_stats.get(x+1)/ath_amount*graph.width(), graph.top + (x+1)/(1f*turns-1)*graph.height(), p);

        }

        p.setTextSize(20);
        p.setColor(Color.RED);
        c.rotate(90,graph.left*1.02f,(graph.top - background.top)/2f);
        text  = "Bust";
        p.getTextBounds(text, 0,text.length(), textRect);
        c.drawText(text ,graph.left*1.02f ,(graph.top - background.top)/2f + textRect.height()/2f, p);
        c.rotate(-90,graph.left*1.02f,(graph.top - background.top)/2f);

        p.setColor(Color.BLACK);
        c.rotate(90,graph.right,(graph.top - background.top)/2f);
        text  = String.format("%.0f",ath_amount);
        p.getTextBounds(text, 0,text.length(), textRect);
        c.drawText(text ,graph.right,(graph.top - background.top)/2f + textRect.height()/2f, p);
        c.rotate(-90,graph.right,(graph.top - background.top)/2f);
        
        p.setColor(Color.BLACK);
        c.rotate(90,graph.left + game_stats.get(0)/ath_amount*graph.width(),(graph.top - background.top)/2f);
        text  = String.valueOf(game_stats.get(0));
        p.getTextBounds(text, 0,text.length(), textRect);
        c.drawText(text ,graph.left + game_stats.get(0)/ath_amount*graph.width(),(graph.top - background.top)/2f + textRect.height()/2f, p);
        c.rotate(-90,graph.left + game_stats.get(0)/ath_amount*graph.width(),(graph.top - background.top)/2f);

        //basic info

        p.setTextSize(30);
        p.setColor(Color.BLACK);
        c.rotate(90, summary.centerX(), summary.centerY());

        if (turns == 2)
            text = "You have spun " + (turns-1) + " time and have $" + game_stats.get(turns-1);
        else
            text = "You have spun " + (turns-1) + " times and have $" + game_stats.get(turns-1);

        p.getTextBounds(text, 0, text.length(), textRect);
        c.drawText(text, summary.centerX(), summary.centerY() - textRect.height() , p);
        c.rotate(-90, summary.centerX(), summary.centerY());

        c.rotate(90, summary.centerX(), summary.centerY());

        if (ath_turn == turns)
            text = "You are at your ATH!";
        else if(turns == 2)
            text = "Your ATH was $" + String.format("%.0f",ath_amount) + ". That was 1 turn ago.";
        else
            text = "Your ATH was $" + String.format("%.0f",ath_amount) + ". That was " + (turns-ath_turn) + " turns ago.";

        p.getTextBounds(text, 0, text.length(), textRect);
        c.drawText(text, summary.centerX(), summary.centerY() + textRect.height(), p);
        c.rotate(-90, summary.centerX(), summary.centerY());

        //buttons
        p.setTextSize(50);

        if(type== WALK_OUT) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0,146,69));
            c.drawRect(continue_game, p);

            p.setColor(Color.WHITE);
            c.rotate(90,continue_game.centerX(),continue_game.centerY());
            text  = "Go Back";
            p.getTextBounds(text, 0,text.length(), textRect);
            c.drawText(text ,continue_game.centerX(),continue_game.centerY() + textRect.height()/2f, p);
            c.rotate(-90,continue_game.centerX(),continue_game.centerY());

            p.setColor(Color.BLACK);
            c.drawRect(end_game, p);

            p.setColor(Color.WHITE);
            c.rotate(90,end_game.centerX(),end_game.centerY());
            text  = "Walk Out";
            p.getTextBounds(text, 0,text.length(), textRect);
            c.drawText(text ,end_game.centerX(),end_game.centerY() + textRect.height()/2f, p);
            c.rotate(-90,end_game.centerX(),end_game.centerY());

        }else if(type== BUST){

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            c.drawRect(end_game, p);

            p.setColor(Color.WHITE);
            c.rotate(90,end_game.centerX(),end_game.centerY());
            text  = "New Game";
            p.getTextBounds(text, 0,text.length(), textRect);
            c.drawText(text ,end_game.centerX(),end_game.centerY() + textRect.height()/2f, p);
            c.rotate(-90,end_game.centerX(),end_game.centerY());

        }


    }


    public int handleTouchEvent(MotionEvent event) {

        float x = event.getX();
        float y = event.getY();

        if (continue_game.contains(x,y))
            return RETURN_TO_BOARD;

        if(end_game.contains(x,y))
            return END_GAME;

        return -1;
    }
}
