package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Square extends Bet{

    private float target1;
    private float target2;
    private float target3;
    private float target4;
    protected float x;
    protected float y;
    protected float radius;

    public Square(float t1_in, float t2_in, float t3_in, float t4_in, float x, float y, float radius){
        target1=t1_in;
        target2=t2_in;
        target3=t3_in;
        target4=t4_in;
        payout = 8;
        this.x=x;
        this.y=y;
        this.radius=radius;
        chip = null;
        area=null;
    }

    public Square(float t1_in, float t2_in, float t3_in, float t4_in, RectF area){
        target1=t1_in;
        target2=t2_in;
        target3=t3_in;
        target4=t4_in;
        payout = 8;
        this.area = area;
        chip = null;
    }

    @Override
    public boolean did_win(int spin_result) {
        return target1 == spin_result || target2 == spin_result || target3 == spin_result || target4 == spin_result;
    }

    @Override
    public boolean contains(float x, float y) {

            if (area !=null)
                return area.contains(x,y);

            return radius >= Math.sqrt((this.x-x)*(this.x-x) + (this.y-y)*(this.y-y));
    }

    @Override
    public void drawBetArea(Canvas canvas, Paint paint, Rect textRect) {
        return;
    }
}
