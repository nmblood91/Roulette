package com.guwop.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public abstract class Bet {
    protected int payout;
    protected Chip chip;
    protected RectF area;

    abstract public boolean did_win(int spin_result);
    abstract public boolean contains(float x, float y);

    public void setChip(Chip c){
        chip =c;
    }

    public Chip getChip(){
        return chip;
    }

    public boolean hasChip()
    {
        return chip != null;
    }

    public int getPayout() { return payout; }

    public abstract void drawBetArea(Canvas canvas, Paint paint, Rect textRect);

    public void drawChip(Canvas c, Paint p) {
        if (hasChip())
            chip.drawChip(c,p);
    }
}